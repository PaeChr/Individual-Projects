import java.util.ArrayList;

public class App {
public static void main(String[] args)
    {
        ArrayList<FootballPlayer>footballPlayers = new ArrayList<>();
        footballPlayers.add(new FootballPlayer("Saquon Barkley"
                ,new Address(26,"Old Main",
                "Street",new ZipCode("16802","0001"),
                "PA"),1,"Football",
                10,80,220));
        footballPlayers.add(new FootballPlayer("John Dunmore"
                ,new Address(8,"Old Main",
                "Street",new ZipCode("16802","0001"),
                "PA"),14,"Football",
                7,120,100));

        footballPlayers.add(new FootballPlayer("Daniel George"
                ,new Address(11,"Old Main",
                "Street",new ZipCode("16802","0001"),
                "PA"),15,"Football",
                5,10,70));

        footballPlayers.add(new FootballPlayer("Will Levis"
                ,new Address(7,"Old Main",
                "Street",new ZipCode("16802","0001"),
                "PA"),20,"Football",
                11,30,250));

        footballPlayers.add(new FootballPlayer("Jaden Dottin"
                ,new Address(19,"Old Main",
                "Street",new ZipCode("16802","0001"),
                "PA"),33,"Football",
                14,100,100));

        for (FootballPlayer player:footballPlayers) {
            System.out.println(player+"\n");
        }

        FootballPlayer temp= footballPlayers.get(0);
        for (FootballPlayer player:footballPlayers) {

            if(temp.getRatings()<player.getRatings())
                temp=player;
        }
        System.out.println(temp.getName()+" has the highest ratings, which is "+String.format("%.2f",temp.getRatings()));

    }
}