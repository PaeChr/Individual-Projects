public class SoccerPlayer extends Player {
    private int goals;
    private int yellowCards;

    public SoccerPlayer() {
        this.goals = 0;
        this.yellowCards = 0;
    }

    public SoccerPlayer(String name, Address address, int number, String sports, int gamesPlayed, int goals, int yellowCards) {
        super(name, address, number, sports, gamesPlayed);
        this.goals = goals;
        this.yellowCards = yellowCards;
    }

    @Override
    public String toString() {
        return super.toString() +
                "\ngoals = " + goals +
                ", yellowCards = " + yellowCards+", Ratings: "+String.format("%.2f",getRatings()) ;
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public int getYellowCards() {
        return yellowCards;
    }

    public void setYellowCards(int yellowCards) {
        this.yellowCards = yellowCards;
    }

    @Override
    public double getRatings() {
        return (double) (goals - yellowCards)/getGamesPlayed();
    }
}