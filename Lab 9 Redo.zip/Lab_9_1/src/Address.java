public class Address {
    private int number;
    private String name;
    private String type;
    private ZipCode zip;
    private String state;

    public Address()
    {
        number=0;
        name ="N/A";
        type = "Unknown";
        zip = new ZipCode();
        state ="  ";
    }

    public Address(int number, String name, String type, ZipCode zip, String state) {
        this.number = number;
        setName(name);
        this.type = type;
        this.zip = zip;
        this.state = state;
    }

    @Override
    public String toString() {
        return "Address: " +
                " number = " + number +
                ", name = '" + name + '\'' +
                ", type = '" + getType() + '\'' +
                "\nzip = " + zip +
                ", state = '" + state + '\'' ;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String[] tokens = name.split(" ");
        if(tokens.length>=2)
            this.name = tokens[0].toUpperCase().charAt(0)+tokens[0].substring(1)+" "
                    + tokens[1].toUpperCase().charAt(0)+tokens[1].substring(1);
        else
           this. name =  tokens[0].toUpperCase().charAt(0)+tokens[0].substring(1);

    }

    public String getType() {
        if(type.equalsIgnoreCase("Drive"))
            return "Dr.";
        if(type.equalsIgnoreCase("Avenue"))
            return "Ave.";
        if(type.equalsIgnoreCase("Street"))
            return "St.";
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ZipCode getZip() {
        return zip;
    }

    public void setZip(ZipCode zip) {
        this.zip = zip;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}