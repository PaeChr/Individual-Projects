public abstract class Player extends Person{
    private int number;
    private String sports;
    private int gamesPlayed;
    
    public Player() {
        this.number = 0;
        this.sports="none";
        this.gamesPlayed=0;
    }

    public Player(String name, Address address, int number, String sports, int gamesPlayed) {
        super(name, address);
        this.number = number;
        this.sports = sports;
        this.gamesPlayed = gamesPlayed;
    }

    @Override
    public String toString() {
        return super.toString() +
                "\nnumber = " + number +
                ", sports = '" + sports + '\'' +", games played: "+gamesPlayed;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getSports() {
        return sports;
    }

    public void setSports(String sports) {
        this.sports = sports;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }
    public abstract double getRatings();
}