public class ZipCode {
    private String fiveDigit;
    private String plus4;

    public ZipCode()
    {
        fiveDigit = "00000";
        plus4 = "0000";
    }

    public ZipCode(String fiveDigit)
    {
        this.fiveDigit= fiveDigit;
        plus4 = "0000";
    }


    public ZipCode(String fiveDigit, String plus4) {
        this.fiveDigit = fiveDigit;
        this.plus4 = plus4;
    }

    @Override
    public String toString() {
        if(fiveDigit.equals(""))
            return plus4;
        else if(plus4.equals(""))
            return fiveDigit;
        else
            return fiveDigit+"-"+plus4;
    }

    public String getFiveDigit() {
        return fiveDigit;
    }

    public void setFiveDigit(String fiveDigit) {
        this.fiveDigit = fiveDigit;
    }

    public String getPlus4() {
        return plus4;
    }

    public void setPlus4(String plus4) {
        this.plus4 = plus4;
    }
    public void display()
    {
        System.out.println(this);
    }

    public void displayPrefix(int p)
    {
        if(p==1)
            System.out.println(fiveDigit.substring(0,3));
        if(p==2)
            System.out.println(fiveDigit.substring(3,5));
    }
}